# quanTIseq

quanTIseq is a computational pipeline for the **quan**tification of the **T**umor **I**mmune contexture from human RNA-**seq** data. 

## Documentation
https://icbi.i-med.ac.at/software/quantiseq/doc/index.html
